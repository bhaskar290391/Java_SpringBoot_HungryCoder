package com.example.hungrycodersSB4series.controller;

import com.example.hungrycodersSB4series.dto.ProductResponseV1;
import com.example.hungrycodersSB4series.dto.ProductResponseV2;
import com.example.hungrycodersSB4series.model.Product;
import com.example.hungrycodersSB4series.service.ProductService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping(version = "1")
    public List<ProductResponseV1> getProductsV1()
    {
     //we call Service method
        return productService.getAllProducts()
                .stream()
                .map(this::toResponseV1)
                .collect(Collectors.toList());
    }

    @GetMapping(version = "2")
    public ProductResponseV2 getProductsV2()
    {
        //we call Service method
        List<Product> listProducts = productService.getAllProducts();
        return toResponseV2(listProducts);
    }

   // @GetMapping(version = "3")
   // public ProductResponseV3 getProductsV3()
   // {
      //implement pagination
  //  }

    private ProductResponseV2 toResponseV2(List<Product> products)
    {
      List<ProductResponseV2.ProductV2> productListV2 =
              products.stream()
                      .map(p -> new ProductResponseV2.ProductV2
                              (
                                 p.id(),
                                 p.name(), p.price(), p.description(),
                                      p.category()
                              )).collect(Collectors.toList());
      return new ProductResponseV2(productListV2, products.size());
    }

    private ProductResponseV1 toResponseV1(Product product)
    {
        return new ProductResponseV1(
                product.id(),
                product.name(),
                product.price()
        );
    }

}
