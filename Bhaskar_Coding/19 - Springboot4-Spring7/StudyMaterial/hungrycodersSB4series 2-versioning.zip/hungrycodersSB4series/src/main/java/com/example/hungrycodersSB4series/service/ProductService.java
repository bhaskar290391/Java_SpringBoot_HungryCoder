package com.example.hungrycodersSB4series.service;

import com.example.hungrycodersSB4series.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    private final List<Product> products;

    public ProductService() {
        //initialize with some mock data
        products = new ArrayList<>();
        products.add(new Product(1L,
                "iphone",
                999.99,
                "Iphone",
                "mobile"));
        products.add(new Product(2L,
                "samsung",
                899.99,
                "Samsung galaxy",
                "mobile"));
        products.add(new Product(3L,
                "airpods",
                599.99,
                "iphone airpods",
                "accessories"));
    }

    public List<Product> getAllProducts()
    {
        return new ArrayList<>(products);
    }
}
