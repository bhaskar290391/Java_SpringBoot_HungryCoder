package com.example.hungrycodersSB4series;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HungrycodersSb4seriesApplication {

	public static void main(String[] args) {

		SpringApplication.run(HungrycodersSb4seriesApplication.class, args);
	}

}
