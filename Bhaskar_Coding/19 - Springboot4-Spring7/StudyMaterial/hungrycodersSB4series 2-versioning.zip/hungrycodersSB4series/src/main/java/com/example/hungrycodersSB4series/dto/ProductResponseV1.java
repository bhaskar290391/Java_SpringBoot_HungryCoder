package com.example.hungrycodersSB4series.dto;

public record ProductResponseV1(
        Long id,
        String name,
        Double price
)
{

}
