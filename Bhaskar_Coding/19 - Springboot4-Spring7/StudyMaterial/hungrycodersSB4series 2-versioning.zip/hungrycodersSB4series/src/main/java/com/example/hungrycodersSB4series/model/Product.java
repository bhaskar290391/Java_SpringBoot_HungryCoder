package com.example.hungrycodersSB4series.model;

//immutability and clean code
//we don't use getters/setters and lombok
public record Product (
    Long id,
    String name,
    Double price,
    String description,
    String category
){
}

