package com.example.hungrycodersSB4series;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HungrycodersSb4seriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
