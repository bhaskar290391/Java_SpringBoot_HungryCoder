package com.example.hungrycodersSB4series.service;

import com.example.hungrycodersSB4series.model.Product;
import org.springframework.resilience.annotation.ConcurrencyLimit;
import org.springframework.resilience.annotation.Retryable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ProductService {

    private final List<Product> products;
    private static AtomicInteger active = new AtomicInteger(0);
    private static AtomicInteger attemptCounter = new AtomicInteger(0);
    public ProductService() {
        //initialize with some mock data
        products = new ArrayList<>();
        products.add(new Product(1L,
                "iphone",
                999.99,
                "Iphone",
                "mobile"));
        products.add(new Product(2L,
                "samsung",
                899.99,
                "Samsung galaxy",
                "mobile"));
        products.add(new Product(3L,
                "airpods",
                599.99,
                "iphone airpods",
                "accessories"));
    }

    @Retryable(
            maxRetries = 4, //Retry up to 4 times after initial failure
            delay = 100, //wait for 100ms before first retry
            jitter = 10, //+-10ms randomness to prevent retry storms
            multiplier = 2, //exponential backoff (100 -> 200 -> 400 -> 800ms)
            maxDelay = 1000 //cap retry delay max at 1000ms
    )
    @ConcurrencyLimit(2)
    public List<Product> getAllProducts() throws InterruptedException {
        //below logs are for ConcurrencyLimit testing
       // int count = active.incrementAndGet();
      //  System.out.println("Started - Active: "+ count);
        // Thread.sleep(5000);
        // active.decrementAndGet();
        // System.out.println("Done - Active: "+ (count-1));

        //below logs are for retryable testing
        int attempt = attemptCounter.incrementAndGet();
        System.out.println("Attempt: " + attempt);

        if(attempt <= 10) //succeed on 4th attempt
        {
            System.out.println("Failed Attempt: " + attempt);
            throw new RuntimeException("simulated external service failure");
        }

        System.out.println("Success Attempt: " + attempt);
        attemptCounter.set(0); //reset for next demo

        return new ArrayList<>(products);
    }



}
