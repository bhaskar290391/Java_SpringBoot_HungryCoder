package com.graphql.hungrycoders.graphql.models;

/**
 * Represents a Post entity with associated details.
 */
public record Post(
        String id,
        String postName,
        String postDescription,
        int likes,
        String commentId) {
}
