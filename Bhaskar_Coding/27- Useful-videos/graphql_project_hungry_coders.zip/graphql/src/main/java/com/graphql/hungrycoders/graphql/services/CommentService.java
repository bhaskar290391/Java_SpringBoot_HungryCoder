package com.graphql.hungrycoders.graphql.services;

import com.graphql.hungrycoders.graphql.models.Comment;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Service class to handle comment-related operations.
 */
@Service
public class CommentService {

    // In-memory list to store comments
    private final List<Comment> comments = List.of(
            new Comment("comment1", "Nice", "16 Feb 2025"),
            new Comment("comment2", "Good explanation", "15 Feb 2025")
    );

    /**
     * Fetches a comment by its ID.
     *
     * @param id Comment ID
     * @return Comment object if found, otherwise null
     */
    public Comment getById(String id) {
        return comments.stream()
                .filter(comment -> comment.id().equals(id))
                .findFirst()
                .orElse(null);
    }
}

