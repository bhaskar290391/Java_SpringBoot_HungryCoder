package com.graphql.hungrycoders.graphql.models;

/**
 * Represents a Comment entity with its details.
 */
public record Comment(
        String id,
        String description,
        String postedDate) {
}
