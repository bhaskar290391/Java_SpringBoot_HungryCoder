package com.graphql.hungrycoders.graphql.services;

import com.graphql.hungrycoders.graphql.models.Post;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

/**
 * Service class to handle post operations such as fetching and creating posts.
 */
@Service
public class PostService {

    // In-memory list to store posts
    private final List<Post> posts = new ArrayList<>(List.of(
            new Post("post-1", "Multithreading", "Multithreading Overview", 550, "comment1"),
            new Post("post-2", "GraphQL", "GraphQL Basics", 333, "comment2")
    ));

    /**
     * Fetches a post by its ID.
     *
     * @param id Post ID
     * @return Post object if found, otherwise null
     */
    public Post getById(String id) {
        return posts.stream()
                .filter(post -> post.id().equals(id))
                .findFirst()
                .orElse(null);
    }

    /**
     * Creates a new post and adds it to the list.
     *
     * @param postId         Unique ID of the post
     * @param postName       Title of the post
     * @param postDescription Description of the post
     * @param likes          Number of likes
     * @param commentId      Associated comment ID
     * @return The newly created Post object
     */
    public Post createPost(String postId, String postName, String postDescription, int likes, String commentId) {
        Post newPost = new Post(postId, postName, postDescription, likes, commentId);
        posts.add(newPost);
        return newPost;
    }
}
