package com.graphql.hungrycoders.graphql;

import jakarta.annotation.PostConstruct;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.TimeZone;

@SpringBootApplication
public class GraphqlApplication {

	public static void main(String[] args) {

				SpringApplication.run(GraphqlApplication.class, args);

	}

}
