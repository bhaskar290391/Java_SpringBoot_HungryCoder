package com.graphql.hungrycoders.graphql.controller;

import com.graphql.hungrycoders.graphql.models.Comment;
import com.graphql.hungrycoders.graphql.models.Post;
import com.graphql.hungrycoders.graphql.services.CommentService;
import com.graphql.hungrycoders.graphql.services.PostService;
import graphql.GraphQLException;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.SchemaMapping;
import org.springframework.stereotype.Controller;

import java.util.Optional;

@Controller
public class PostController {

    private final PostService postService;
    private final CommentService commentService;

    public PostController(PostService postService, CommentService commentService) {
        this.postService = postService;
        this.commentService = commentService;
    }

    @QueryMapping
    public Post postById(@Argument String id) {
        return Optional.ofNullable(postService.getById(id))
                .orElseThrow(() -> new GraphQLException("Post not found with ID: " + id));
    }

    @SchemaMapping
    public Comment comment(Post post) {
        if (post.commentId() == null) {
            return null; // Avoid unnecessary DB calls
        }
        return Optional.ofNullable(commentService.getById(post.commentId()))
                .orElse(null); // Return null if comment doesn’t exist, avoiding exceptions
    }

    @MutationMapping
    public Post createPost(@Argument String postId,
                           @Argument String postName,
                           @Argument String postDescription,
                           @Argument int likes,
                           @Argument String commentId) {
        // Basic validation
        if (postId == null || postName == null || postDescription == null) {
            throw new GraphQLException("Post ID, name, and description are required.");
        }
        if (likes < 0) {
            throw new GraphQLException("Likes cannot be negative.");
        }
        return postService.createPost(postId, postName, postDescription, likes, commentId);
    }
}