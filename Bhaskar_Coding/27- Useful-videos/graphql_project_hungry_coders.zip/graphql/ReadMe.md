# 🚀 GraphQL API with Spring Boot by HungryCoders

## **📌 Overview**

Welcome to the **GraphQL API with Spring Boot**. This project demonstrates how to build a **GraphQL API** using **Spring Boot**, where data is stored in-memory using **ArrayList** instead of a database.

### **🛠 Features**

- 📡 **GraphQL Queries & Mutations**
- ⚡ **In-Memory Storage** (ArrayList)
- 🎯 **Spring Boot with GraphQL Starter**
- 🔍 **Schema Mapping for Resolvers**

---

## **📁 Project Structure**

```
graphql-project/
│── src/
│   ├── main/
│   │   ├── java/com/graphql/hungrycoders/graphql/
│   │   │   ├── controller/       # GraphQL Controllers (Resolvers)
│   │   │   ├── models/           # Data Models (Post, Comment)
│   │   │   ├── services/         # Business Logic (Service Layer)
│   │   │   ├── GraphqlApplication.java  # Main Application
│   │   ├── resources/
│   │   │   ├── application.properties   # Configuration
│   │   │   ├── graphql/schema.graphqls  # GraphQL Schema
│── pom.xml                        # Project Dependencies
│── README.md                      # Documentation
```

---

## **⚙️ Dependencies**

This project uses **Spring Boot 3** and **Spring GraphQL**.

### **📌 Add the following dependencies in `pom.xml`:**

```xml
<dependencies>
    <!-- Spring Boot Starter for GraphQL -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-graphql</artifactId>
    </dependency>

    <!-- Spring Boot Starter for Web -->
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
</dependencies>
```

---

## **🛠️ Setup & Running the Application**

### **Build & Run**

```sh
mvn clean install
mvn spring-boot:run
```

---

## **📜 GraphQL Schema (`schema.graphqls`)**

This defines the **GraphQL API structure**.

```graphql
type Query {
    postById(id: ID!): Post!
}

type Mutation {
    createPost(
        postId: ID!,
        postName: String!,
        postDescription: String!,
        likes: Int!,
        commentId: ID
    ): Post!
}

type Post {
    id: ID!
    postName: String!
    postDescription: String!
    likes: Int!
    comment: Comment
}

type Comment {
    id: ID!
    description: String!
    postedDate: String!
}
```

---

## **🔍 Query & Mutation Examples**

### **1️⃣ Fetch a Post by ID**

```graphql
query {
  postById(id: "post-1") {
    id
    postName
    postDescription
    comment {
      id
      description
      postedDate
    }
  }
}
```

### **2️⃣ Create a New Post**

```graphql
mutation {
  createPost(
    postId: "post-3",
    postName: "GraphQL in Spring Boot",
    postDescription: "An introduction to GraphQL",
    likes: 100,
    commentId: "comment1"
  ) {
    id
    postName
    postDescription
  }
}
```

---

## **🛠️ Testing the API**

### **1️⃣ Using GraphiQL (UI Tool)**

- Enable GraphiQL in `application.properties`:

```properties
spring.graphql.graphiql.enabled=true
```

- Open **GraphiQL** in browser: 👉 `http://localhost:8080/graphiql`

### **2️⃣ Using Postman**

- **Method:** `POST`
- **URL:** `http://localhost:8080/graphql`
- **Body (Raw - JSON)**:

```json
{
  "query": "query { postById(id: "post-1") { id postName postDescription } }"
}
```

---

## **📌 Troubleshooting**

| **Issue**                                          | **Solution**                                            |
| -------------------------------------------------- | ------------------------------------------------------- |
| `Error: "Tried to redefine existing 'Query' type"` | Ensure you have **only one `.graphqls` file**.               |
| `NullPointerException on comment()`                | Ensure `commentId` exists before querying for comments. |

